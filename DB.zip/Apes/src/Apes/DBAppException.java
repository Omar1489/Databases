package Apes;

public class DBAppException extends Exception {

	public DBAppException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DBAppException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
}
