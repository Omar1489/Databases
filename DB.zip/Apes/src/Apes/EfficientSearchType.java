package Apes;

public enum EfficientSearchType {
	Indexed , Binary;
}
