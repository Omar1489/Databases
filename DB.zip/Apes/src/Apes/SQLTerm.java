package Apes;

public class SQLTerm {
	String _strTableName;
	String _strColumnName;
	String _strOperator;
	Object _objValue;
	public SQLTerm() {
		super();
	}
	public String get_strTableName() {
		return _strTableName;
	}
	public String get_strColumnName() {
		return _strColumnName;
	}
	public String get_strOperator() {
		return _strOperator;
	}
	public Object get_objValue() {
		return _objValue;
	}
	
	
}
